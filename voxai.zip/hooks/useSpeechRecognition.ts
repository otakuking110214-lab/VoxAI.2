import { useState, useEffect, useRef, useCallback } from 'react';

// Define the type for the SpeechRecognition API to handle vendor prefixes
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
}

// Access the API, checking for vendor prefixes
const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

interface UseSpeechRecognitionProps {
  onTranscriptChange: (transcript: string) => void;
  initialPrompt: string;
}

export const useSpeechRecognition = ({ onTranscriptChange, initialPrompt }: UseSpeechRecognitionProps) => {
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  
  // Ref to store the transcript part that is considered "final" by the API
  const finalTranscriptRef = useRef<string>('');
  
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, []);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
        // When starting, the final transcript should be what's already in the text area
        finalTranscriptRef.current = initialPrompt ? initialPrompt.trim() + ' ' : '';
        setIsListening(true);
        recognitionRef.current.start();
    }
  }, [isListening, initialPrompt]);

  const toggleListening = useCallback(() => {
    isListening ? stopListening() : startListening();
  }, [isListening, startListening, stopListening]);
  
  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      setError("Speech recognition is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let currentFinalTranscript = finalTranscriptRef.current;

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcriptPart = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          // Reset and append the final part
          finalTranscriptRef.current += transcriptPart;
          currentFinalTranscript = finalTranscriptRef.current;
        } else {
          interimTranscript += transcriptPart;
        }
      }
      onTranscriptChange(currentFinalTranscript + interimTranscript);
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        setError(`Speech recognition error: ${event.error}`);
      }
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if(recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [onTranscriptChange]);

  return {
    isListening,
    error,
    toggleListening,
    isSupported: !!SpeechRecognitionAPI
  };
};