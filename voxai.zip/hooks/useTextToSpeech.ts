import { useState, useRef, useCallback, useEffect } from 'react';

interface UseTextToSpeechProps {
  onEnd?: () => void;
}

export const useTextToSpeech = ({ onEnd }: UseTextToSpeechProps = {}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const isSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  useEffect(() => {
    if (!isSupported) return;
    const loadVoices = () => {
      setVoices(window.speechSynthesis.getVoices());
    };
    window.speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices(); // For browsers that load voices immediately

    // Workaround for a bug in some browsers (e.g., Chrome) where the speech synthesis engine
    // can become unresponsive after a period of inactivity. This interval "pings" the engine.
    const keepAliveInterval = setInterval(() => {
      if (isSupported) {
        if (speechSynthesis.paused) {
          speechSynthesis.resume();
        } else if (!speechSynthesis.speaking) {
          speechSynthesis.resume();
        }
      }
    }, 10000);

    return () => {
      if (isSupported) {
        window.speechSynthesis.onvoiceschanged = null;
        window.speechSynthesis.cancel();
      }
      clearInterval(keepAliveInterval);
    };
  }, [isSupported]);

  const handleEnd = useCallback(() => {
    setIsSpeaking(false);
    if (utteranceRef.current) {
      utteranceRef.current.onend = null;
      utteranceRef.current.onerror = null;
      utteranceRef.current = null;
    }
    if (onEnd) {
      onEnd();
    }
  }, [onEnd]);

  const speak = useCallback(async (text: string) => {
    if (!isSupported || !text.trim()) return;

    // Reset from any previous state before starting.
    // This handles interruptions and resets the engine.
    window.speechSynthesis.cancel();
    
    // A short delay helps prevent race conditions on some browsers.
    await new Promise(resolve => setTimeout(resolve, 50));

    setIsSpeaking(true);

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;

      // Prioritize high-quality, natural-sounding voices
      const preferredVoices = [
        'neural', 'eloquent', 'natural',
        'Google US English', 'Microsoft David Desktop - English (United States)', 'Microsoft Zira Desktop - English (United States)', 'Samantha', 'Alex',
      ];

      const enUSVoices = voices.filter(v => v.lang.startsWith('en-US'));
      
      let selectedVoice: SpeechSynthesisVoice | undefined;

      for (const keyword of preferredVoices) {
          selectedVoice = enUSVoices.find(v => v.name.toLowerCase().includes(keyword.toLowerCase()));
          if (selectedVoice) break;
      }

      // Fallback to the first available US English voice
      if (!selectedVoice && enUSVoices.length > 0) {
        selectedVoice = enUSVoices[0];
      }
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
      
      utterance.pitch = 1;
      utterance.rate = 1;
      utterance.volume = 1;
      
      utterance.onend = handleEnd;
      utterance.onerror = (event: SpeechSynthesisErrorEvent) => {
        console.error(`SpeechSynthesisUtterance.onerror: ${event.error}`, event);
        handleEnd();
      };
      
      window.speechSynthesis.speak(utterance);

    } catch (error) {
      console.error('Error with browser text-to-speech:', error);
      handleEnd();
    }
  }, [isSupported, handleEnd, voices]);
  
  const cancel = useCallback(() => {
    if (isSupported) {
      window.speechSynthesis.cancel();
      // Manually clean up state since 'end' event doesn't fire on cancel.
      handleEnd();
    }
  }, [isSupported, handleEnd]);

  // Cleanup on unmount
  useEffect(() => {
    return cancel;
  }, [cancel]);

  return { speak, cancel, isSpeaking, isSupported };
};