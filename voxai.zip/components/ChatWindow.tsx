import React, { useEffect, useRef } from 'react';
import { ChatMessage, ChatRole, ChatMode } from '../types';
import Message from './Message';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
  isNewChat: boolean;
  chatMode: ChatMode;
  onSendMessage: (prompt: string) => void;
  speakingMessageId: string | null;
  onToggleSpeak: (message: ChatMessage) => void;
}

const LoadingIndicator: React.FC = () => (
  <div className="flex items-center justify-start space-x-2 p-4">
    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse"></div>
  </div>
);

const MODE_CONFIG = {
  default: {
    title: "What's on your mind today?",
    suggestions: []
  },
  image: {
    title: "Describe an image to create",
    suggestions: []
  },
  think: {
    title: "What topic do you want to explore?",
    suggestions: [
      "The philosophical implications of artificial intelligence",
      "A detailed breakdown of the causes of the fall of the Roman Empire",
      "Analyze the major themes in the movie 'Blade Runner'",
      "Provide a counter-argument for the benefits of social media",
    ]
  },
  research: {
    title: "What are you researching?",
    suggestions: [
      "The latest breakthroughs in cancer research",
      "The economic impact of climate change",
      "A summary of recent discoveries from the James Webb Space Telescope",
      "Compare and contrast the political systems of the US and the UK",
    ]
  },
  study: {
    title: "Learn something new",
    suggestions: [
      "Help me with my homework on the water cycle",
      "Explain the concept of machine learning using a simple analogy",
      "Create a 10-question practice quiz on World War II",
      "Outline the key principles of effective public speaking",
    ]
  }
};


const SuggestionButton: React.FC<{ text: string; onClick: (prompt: string) => void; }> = ({ text, onClick }) => (
  <button
    onClick={() => onClick(text)}
    className="text-left p-3 border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-sm"
  >
    {text}
  </button>
);


const ModeSuggestions: React.FC<{ chatMode: ChatMode, onSendMessage: (prompt: string) => void }> = ({ chatMode, onSendMessage }) => {
  const config = MODE_CONFIG[chatMode || 'default'];

  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-4">
      <div className="flex-1 flex flex-col justify-center items-center -mt-20"> 
          <h1 className="text-4xl font-bold text-cyan-600 dark:text-cyan-400 tracking-wider mb-4">
              VoxAI
          </h1>
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200">{config.title}</h2>
      </div>
      <div className="w-full max-w-3xl pb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {config.suggestions.map(prompt => (
              <SuggestionButton key={prompt} text={prompt} onClick={onSendMessage} />
            ))}
          </div>
      </div>
    </div>
  );
};


const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, isNewChat, chatMode, onSendMessage, speakingMessageId, onToggleSpeak }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current && !isNewChat) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, isNewChat]);

  const isOnlyUserMessageLoading = isLoading && messages[messages.length-1]?.role === ChatRole.USER;

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto pt-10">
      {isNewChat && !isOnlyUserMessageLoading ? (
        <ModeSuggestions chatMode={chatMode} onSendMessage={onSendMessage} />
      ) : (
        <div className="p-4 space-y-4">
          {messages.map((msg) => (
            <Message
              key={msg.id}
              message={msg}
              isSpeaking={speakingMessageId === msg.id}
              onToggleSpeak={onToggleSpeak}
            />
          ))}
          {isOnlyUserMessageLoading && <LoadingIndicator />}
        </div>
      )}
    </div>
  );
};

export default ChatWindow;