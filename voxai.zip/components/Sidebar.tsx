import React, { useState, useRef, useEffect } from 'react';
import { ChatSession } from '../types';
import NewChatIcon from './icons/NewChatIcon';
import PencilIcon from './icons/PencilIcon';
import CheckIcon from './icons/CheckIcon';
import XIcon from './icons/XIcon';
import SearchIcon from './icons/SearchIcon';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  activeChatId: string | null;
  onNewChat: () => void;
  onSwitchChat: (id: string) => void;
  onUpdateChatTitle: (id: string, title: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, sessions, activeChatId, onNewChat, onSwitchChat, onUpdateChatTitle }) => {
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingSessionId && editInputRef.current) {
      editInputRef.current.focus();
    }
  }, [editingSessionId]);

  const handleSwitchChat = (id: string) => {
    if (editingSessionId !== id) {
      onSwitchChat(id);
      onClose();
    }
  };

  const handleNewChat = () => {
    setSearchQuery('');
    onNewChat();
    onClose();
  };

  const handleStartEditing = (session: ChatSession) => {
    setEditingSessionId(session.id);
    setEditingTitle(session.title);
  };

  const handleCancelEdit = () => {
    setEditingSessionId(null);
    setEditingTitle('');
  };

  const handleSaveTitle = () => {
    if (editingSessionId && editingTitle.trim()) {
      onUpdateChatTitle(editingSessionId, editingTitle);
    }
    handleCancelEdit();
  };
  
  const handleEditKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSaveTitle();
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  }

  const filteredSessions = searchQuery
    ? sessions.filter(session => session.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : sessions;

  return (
    <>
      <div
        className={`fixed inset-0 bg-gray-900/60 z-30 md:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
        aria-hidden="true"
      />

      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-white dark:bg-black border-r border-gray-200 dark:border-gray-800 z-40 transform transition-transform flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-4 border-b border-gray-200 dark:border-gray-800">
          <button
            onClick={handleNewChat}
            className="w-full flex items-center justify-center gap-2 p-2 rounded-lg text-sm font-semibold bg-gray-800 text-white hover:bg-black dark:bg-gray-200 dark:text-black dark:hover:bg-white transition-colors duration-200"
          >
            <NewChatIcon />
            New Chat
          </button>
        </div>
        <div className="p-2 border-b border-gray-200 dark:border-gray-800">
            <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <SearchIcon className="h-4 w-4 text-gray-400 dark:text-gray-500" />
                </span>
                <input
                    type="text"
                    placeholder="Search chats..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-gray-100 dark:bg-gray-900 text-sm rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-gray-500 border border-transparent"
                />
            </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-2">
          <ul className="space-y-1">
            {filteredSessions.map((session) => (
              <li key={session.id} className="relative group">
                {editingSessionId === session.id ? (
                  <div className="flex items-center gap-1 p-1">
                    <input
                      ref={editInputRef}
                      type="text"
                      value={editingTitle}
                      onChange={(e) => setEditingTitle(e.target.value)}
                      onKeyDown={handleEditKeyDown}
                      onBlur={handleCancelEdit} // Cancel on blur for simplicity
                      className="w-full bg-gray-100 dark:bg-gray-800 text-sm rounded-md p-1.5 focus:outline-none focus:ring-2 focus:ring-gray-500"
                    />
                    <button onClick={handleSaveTitle} className="p-1 text-gray-500 hover:text-green-500 dark:hover:text-green-400"><CheckIcon /></button>
                    <button onClick={handleCancelEdit} className="p-1 text-gray-500 hover:text-red-500 dark:hover:text-red-400"><XIcon /></button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleSwitchChat(session.id)}
                    className={`w-full text-left p-2.5 text-sm rounded-md truncate transition-colors flex items-center justify-between ${
                      session.id === activeChatId
                        ? 'bg-gray-200 dark:bg-gray-800 text-black dark:text-white font-semibold'
                        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-900'
                    }`}
                  >
                    <span className="truncate flex-1">{session.title}</span>
                    <span
                      onClick={(e) => { e.stopPropagation(); handleStartEditing(session); }}
                      className="ml-2 p-1 rounded-md opacity-0 group-hover:opacity-100 text-gray-400 dark:text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300"
                      aria-label="Edit title"
                    >
                      <PencilIcon />
                    </span>
                  </button>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;