import React from 'react';
import SunIcon from './icons/SunIcon';
import MoonIcon from './icons/MoonIcon';
import MenuIcon from './icons/MenuIcon';
import VolumeIcon from './icons/VolumeIcon';
import VolumeOffIcon from './icons/VolumeOffIcon';

interface HeaderProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  toggleSidebar: () => void;
  isTtsEnabled: boolean;
  toggleTts: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, toggleTheme, toggleSidebar, isTtsEnabled, toggleTts }) => {
  return (
    <header className="relative p-4 border-b border-gray-200 dark:border-gray-800 text-center flex-shrink-0">
      <div className="absolute top-1/2 left-4 -translate-y-1/2">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500"
          aria-label="Toggle sidebar"
        >
          <MenuIcon />
        </button>
      </div>
      
      <h1 className="text-2xl font-bold text-cyan-600 dark:text-cyan-400 tracking-wider">
        VoxAI
      </h1>
      <p className="text-sm text-gray-500 dark:text-gray-400">
        unfilterd VOXAI
      </p>

      <div className="absolute top-1/2 right-4 -translate-y-1/2 flex items-center gap-2">
        <button
          onClick={toggleTts}
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500"
          aria-label={isTtsEnabled ? 'Disable text-to-speech' : 'Enable text-to-speech'}
        >
          {isTtsEnabled ? <VolumeIcon /> : <VolumeOffIcon />}
        </button>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500"
          aria-label="Toggle theme"
        >
          {theme === 'light' ? <SunIcon /> : <MoonIcon />}
        </button>
      </div>
    </header>
  );
};

export default Header;
