import React from 'react';

const VolumeOffIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
    <path d="M15 8a5 5 0 0 1 1.71 3.285m.29 3.715a5 5 0 0 1 -2 1" />
    <path d="M17.7 5a9 9 0 0 1 2.362 5.07m-.162 4.23a9 9 0 0 1 -2.2 4.7" />
    <path d="M6 15h-2a1 1 0 0 1 -1 -1v-4a1 1 0 0 1 1 -1h2l3.5 -4.5a.8 .8 0 0 1 1.5 .5v2.5m0 4v7a.8 .8 0 0 1 -1.5 .5l-3.5 -4.5" />
    <line x1="3" y1="3" x2="21" y2="21" />
  </svg>
);

export default VolumeOffIcon;
