
import React from 'react';

const BrainIcon: React.FC = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    className="h-6 w-6" 
    viewBox="0 0 24 24" 
    strokeWidth="2" 
    stroke="currentColor" 
    fill="none" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
    <path d="M15.5 13a3.5 3.5 0 0 0 -3.5 3.5v1a3.5 3.5 0 0 0 7 0v-1.8" />
    <path d="M8.5 13a3.5 3.5 0 0 1 3.5 3.5v1a3.5 3.5 0 0 1 -7 0v-1.8" />
    <path d="M17.5 16a3.5 3.5 0 0 0 0 -7h-1.5" />
    <path d="M6.5 16a3.5 3.5 0 0 1 0 -7h1.5" />
    <path d="M16 5.5a3.5 3.5 0 0 0 -3.5 3.5" />
    <path d="M8 5.5a3.5 3.5 0 0 1 3.5 3.5" />
    <line x1="12" y1="4" x2="12" y2="12" />
  </svg>
);

export default BrainIcon;
