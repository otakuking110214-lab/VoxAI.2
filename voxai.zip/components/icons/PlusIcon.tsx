
import React from 'react';

const PlusIcon: React.FC<{ isOpen?: boolean }> = ({ isOpen = false }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className="h-6 w-6 transform transition-transform duration-300 ease-in-out"
    viewBox="0 0 24 24"
    strokeWidth="2"
    stroke="currentColor"
    fill="none"
    strokeLinecap="round"
    strokeLinejoin="round"
    style={{ transform: isOpen ? 'rotate(45deg)' : 'rotate(0deg)' }}
  >
    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);

export default PlusIcon;
