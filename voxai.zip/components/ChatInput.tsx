import React, { useState, useEffect, useRef } from 'react';
import SendIcon from './icons/SendIcon';
import PlusIcon from './icons/PlusIcon';
import ShortcutMenu from './ShortcutMenu';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import MicrophoneIcon from './icons/MicrophoneIcon';
import { ChatMode, FilePart } from '../types';
import XIcon from './icons/XIcon';

interface ChatInputProps {
  onSendMessage: (prompt: string, file?: FilePart) => void;
  isLoading: boolean;
  chatMode: ChatMode;
  setChatMode: (mode: ChatMode) => void;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading, chatMode, setChatMode }) => {
  const [prompt, setPrompt] = useState('');
  const [file, setFile] = useState<FilePart & { name: string } | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [speechErrorMessage, setSpeechErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { isListening, error: speechError, toggleListening, isSupported } = useSpeechRecognition({
    onTranscriptChange: setPrompt,
    initialPrompt: prompt,
  });

  useEffect(() => {
    if (speechError) {
      console.error("Speech recognition error:", speechError);
      setSpeechErrorMessage(speechError);
      const timer = setTimeout(() => setSpeechErrorMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [speechError]);
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
        if (selectedFile.size > 2 * 1024 * 1024) { // 2MB limit
            alert("File is too large. Please select a file smaller than 2MB.");
            return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            setFile({ 
                data: base64String, 
                mimeType: selectedFile.type,
                name: selectedFile.name 
            });
            setChatMode(null); // Exit any mode when a file is attached
        };
        reader.readAsDataURL(selectedFile);
    }
    // Reset the input value to allow selecting the same file again
    if(event.target) event.target.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isListening) {
      toggleListening();
    }
    if ((prompt.trim() || file) && !isLoading) {
      onSendMessage(prompt, file ? { data: file.data, mimeType: file.mimeType } : undefined);
      setPrompt('');
      setFile(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as unknown as React.FormEvent);
    }
  };
  
  const triggerFilePicker = () => {
    fileInputRef.current?.click();
    setIsMenuOpen(false);
  };

  const getModeInfo = () => {
    switch (chatMode) {
      case 'image': return { label: 'Create Image', placeholder: 'Describe the image you want to create...' };
      case 'think': return { label: 'Think Longer', placeholder: 'Enter a topic, claim, or idea to explore...' };
      case 'research': return { label: 'Deep Research', placeholder: 'Enter a topic to research...' };
      case 'study': return { label: 'Study and Learn', placeholder: 'What do you want to learn? (e.g., "React in 2 weeks")' };
      default: return { label: '', placeholder: isListening ? "Listening..." : "Ask me anything..." };
    }
  };

  const { label, placeholder } = getModeInfo();

  return (
    <div className="w-full">
      <div className="relative">
        <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange}
            accept="image/*"
            style={{ display: 'none' }} 
        />
        {isMenuOpen && (
          <ShortcutMenu
            onSetMode={(mode) => {
              setChatMode(mode);
              setFile(null); // Clear file when setting a mode
              setIsMenuOpen(false);
            }}
            onFileUploadClick={triggerFilePicker}
            onClose={() => setIsMenuOpen(false)}
          />
        )}
        
        {speechErrorMessage && (
          <div 
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-300 text-xs rounded-md shadow-lg transition-opacity duration-300"
            role="alert"
          >
            {speechErrorMessage}
          </div>
        )}
        
        {file && (
            <div className="mb-2 flex items-center justify-between text-xs p-1.5 pl-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
                <span className="font-semibold text-gray-600 dark:text-gray-300 truncate">
                    Attached: <span className="text-gray-800 dark:text-gray-200">{file.name}</span>
                </span>
                <button 
                    onClick={() => setFile(null)} 
                    className="flex items-center gap-1 text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 p-1 rounded-md flex-shrink-0"
                    aria-label="Remove file"
                >
                    <XIcon />
                </button>
            </div>
        )}

        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsMenuOpen(prev => !prev)}
            className="p-3 bg-gray-200 dark:bg-gray-800 rounded-full text-gray-600 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-700 disabled:opacity-50 transition-colors duration-200 flex-shrink-0"
            aria-label="Open shortcuts menu"
            aria-expanded={isMenuOpen}
            disabled={!!file}
          >
            <PlusIcon isOpen={isMenuOpen} />
          </button>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={file ? "Describe the image or ask a question..." : placeholder}
            disabled={isLoading}
            rows={1}
            className="flex-1 p-3 bg-gray-100 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-50"
          />
          {isSupported && (
            <button
              type="button"
              onClick={toggleListening}
              className={`p-3 rounded-full text-white transition-colors duration-200 flex-shrink-0 ${isListening ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-gray-700 hover:bg-gray-800 dark:bg-gray-600 dark:hover:bg-gray-500'}`}
              aria-label={isListening ? 'Stop recording' : 'Start recording'}
            >
              <MicrophoneIcon />
            </button>
          )}
          <button
            type="submit"
            disabled={isLoading || (!prompt.trim() && !file)}
            className="p-3 bg-gray-800 rounded-full text-white hover:bg-black dark:bg-gray-200 dark:text-black dark:hover:bg-white disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors duration-200 flex-shrink-0"
          >
            <SendIcon />
          </button>
        </form>
      </div>

      {chatMode && (
        <div className="mt-2 text-xs p-1.5 pl-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
            <span className="font-semibold text-gray-600 dark:text-gray-300">
                Mode: <span className="text-gray-800 dark:text-gray-200">{label}</span>
            </span>
            <button 
                onClick={() => setChatMode(null)} 
                className="ml-2 font-semibold text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:underline focus:outline-none"
                aria-label={`Cancel ${label} mode`}
            >
                cancel
            </button>
        </div>
      )}
    </div>
  );
};

export default ChatInput;