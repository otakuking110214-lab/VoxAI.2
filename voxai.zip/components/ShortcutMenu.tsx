import React, { useRef, useEffect, useState } from 'react';
import SparklesIcon from './icons/SparklesIcon';
import LightbulbIcon from './icons/LightbulbIcon';
import SearchIcon from './icons/SearchIcon';
import BookIcon from './icons/BookIcon';
import PhotoIcon from './icons/PhotoIcon';
import { ChatMode } from '../types';

interface ShortcutMenuProps {
  onSetMode: (mode: NonNullable<ChatMode>) => void;
  onFileUploadClick: () => void;
  onClose: () => void;
}

const ShortcutMenu: React.FC<ShortcutMenuProps> = ({ onSetMode, onFileUploadClick, onClose }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsMounted(true), 10);
    
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        if (!(event.target as HTMLElement).closest('[aria-expanded]')) {
             onClose();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      clearTimeout(timer);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  type MenuItem = 
    | { type: 'mode'; label: string; icon: React.ReactElement; mode: NonNullable<ChatMode> }
    | { type: 'action'; label: string; icon: React.ReactElement; action: () => void };

  const menuItems: MenuItem[] = [
    { type: 'action', label: 'Add photos and files', icon: <PhotoIcon />, action: onFileUploadClick },
    { type: 'mode', label: 'Create image', icon: <SparklesIcon />, mode: 'image' },
    { type: 'mode', label: 'Think longer', icon: <LightbulbIcon />, mode: 'think' },
    { type: 'mode', label: 'Deep research', icon: <SearchIcon />, mode: 'research' },
    { type: 'mode', label: 'Study and learn', icon: <BookIcon />, mode: 'study' },
  ];
  
  const containerClasses = `
    absolute bottom-full left-0 mb-2 w-60
    origin-bottom-left transition-all duration-200 ease-out
    bg-white dark:bg-gray-900 
    rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700
    ${isMounted ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}
  `;

  return (
    <div
      ref={menuRef}
      className={containerClasses}
      role="menu"
      aria-orientation="vertical"
      aria-labelledby="menu-button"
    >
      <ul className="p-2" role="none">
        {menuItems.map((item) => (
          <li key={item.label} role="none">
            <button
              onClick={() => {
                if (item.type === 'mode') {
                    onSetMode(item.mode);
                } else {
                    item.action();
                }
                onClose(); 
              }}
              className="w-full flex items-center gap-3 p-2.5 text-sm text-left rounded-lg transition-colors
                         text-gray-800 dark:text-gray-200 
                         hover:bg-gray-100 dark:hover:bg-gray-800
                         focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-800"
              role="menuitem"
            >
              <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-gray-500 dark:text-gray-400">
                {item.icon}
              </div>
              <span className="flex-1 font-medium">{item.label}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ShortcutMenu;
