import React, { useState } from 'react';
import { ChatMessage, ChatRole } from '../types';
import RobotIcon from './icons/RobotIcon';
import UserIcon from './icons/UserIcon';
import ClipboardIcon from './icons/ClipboardIcon';
import CheckIcon from './icons/CheckIcon';
import SpeakerIcon from './icons/SpeakerIcon';
import SpeakerWaveIcon from './icons/SpeakerWaveIcon';

interface MessageProps {
  message: ChatMessage;
  isSpeaking: boolean;
  onToggleSpeak: (message: ChatMessage) => void;
}

const Message: React.FC<MessageProps> = ({ message, isSpeaking, onToggleSpeak }) => {
  const [copied, setCopied] = useState(false);
  const isModel = message.role === ChatRole.MODEL;

  const handleCopy = () => {
    let textToCopy = message.content;
    if (message.sources && message.sources.length > 0) {
        const sourcesText = message.sources.map(s => `- ${s.web.title || 'Untitled'}: ${s.web.uri}`).join('\n');
        textToCopy += `\n\nSources:\n${sourcesText}`;
    }

    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const wrapperClasses = `group flex items-start gap-3 ${isModel ? 'justify-start' : 'justify-end'}`;
  const messageClasses = `max-w-xl rounded-lg px-4 py-3 ${isModel ? 'bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white' : 'bg-gray-800 dark:bg-gray-300 text-white dark:text-black'}`;
  const icon = isModel ? <RobotIcon /> : <UserIcon />;

  const hasContent = message.content || message.imageUrl || (message.sources && message.sources.length > 0);
  const canSpeak = isModel && message.content && message.content.trim().length > 0;

  return (
    <div className={wrapperClasses}>
      {isModel && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
          {icon}
        </div>
      )}
      <div className={messageClasses}>
        {message.imageUrl && (
            <div className="mb-2 p-1 bg-gray-200 dark:bg-gray-700 rounded-lg inline-block">
                <img src={message.imageUrl} alt="Generated content" className="max-w-xs w-full rounded-md" />
            </div>
        )}
        
        {message.content && <div style={{ whiteSpace: 'pre-wrap' }}>{message.content}</div>}

        {message.sources && message.sources.length > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-2">Sources:</h4>
                <ul className="list-decimal list-inside space-y-1">
                    {message.sources.map((source, index) => (
                        <li key={index} className="text-xs truncate">
                            <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-gray-700 dark:text-gray-300 hover:underline">
                                {source.web.title || source.web.uri}
                            </a>
                        </li>
                    ))}
                </ul>
            </div>
        )}

        {!hasContent && !message.imageUrl && <span className="inline-block w-2 h-5 bg-gray-300 dark:bg-white animate-pulse" />}
      </div>
       
      {isModel && hasContent && (
        <div className="self-center flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-all duration-200">
          {canSpeak && (
            <button
              onClick={() => onToggleSpeak(message)}
              className="p-1.5 rounded-md text-gray-400 dark:text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
              aria-label={isSpeaking ? 'Stop speaking' : 'Read message aloud'}
            >
              {isSpeaking ? <SpeakerWaveIcon /> : <SpeakerIcon />}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-md text-gray-400 dark:text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-100 disabled:text-green-500 dark:disabled:text-green-400"
            aria-label={copied ? 'Copied' : 'Copy message'}
            disabled={copied}
          >
            {copied ? <CheckIcon /> : <ClipboardIcon />}
          </button>
        </div>
      )}

      {!isModel && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-700 dark:bg-gray-300 flex items-center justify-center">
          {icon}
        </div>
      )}
    </div>
  );
};

export default Message;
