export enum ChatRole {
  USER = 'user',
  MODEL = 'model',
}

export interface FilePart {
  data: string; // base64 encoded
  mimeType: string;
}

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  imageUrl?: string;
  sources?: { web: { uri: string; title: string; } }[];
  file?: FilePart; // For multimodal input
}

export interface ChatSession {
  id: string;
  title: string;
  lastUpdated: number;
}

export type ChatMode = 'image' | 'think' | 'research' | 'study' | null;
