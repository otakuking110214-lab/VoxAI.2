import React, { useState, useEffect, useCallback } from 'react';
import ChatWindow from './components/ChatWindow';
import ChatInput from './components/ChatInput';
import Header from './components/Header';
import { useChat } from './hooks/useChat';
import Sidebar from './components/Sidebar';
import { ChatRole, ChatMessage } from './types';
import { useTextToSpeech } from './hooks/useTextToSpeech';

const getInitialTheme = (): 'light' | 'dark' => {
  if (typeof window !== 'undefined' && window.localStorage) {
    const storedPrefs = window.localStorage.getItem('voxai-theme');
    if (typeof storedPrefs === 'string' && (storedPrefs === 'light' || storedPrefs === 'dark')) {
      return storedPrefs;
    }

    const userMedia = window.matchMedia('(prefers-color-scheme: dark)');
    if (userMedia.matches) {
      return 'dark';
    }
  }
  return 'dark'; // Default to dark
};


function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(getInitialTheme);
  const { messages, sendMessage, isLoading, error, chatSessions, activeChatId, startNewChat, switchChat, updateChatTitle, chatMode, setChatMode } = useChat();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // TTS State
  const [isTtsEnabled, setIsTtsEnabled] = useState(true);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  
  const { speak, cancel, isSpeaking } = useTextToSpeech({
    onEnd: () => setSpeakingMessageId(null),
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('voxai-theme', theme);
  }, [theme]);

  // Effect to cancel speech if TTS is disabled
  useEffect(() => {
    if (!isTtsEnabled) {
      cancel();
    }
  }, [isTtsEnabled, cancel]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const toggleTts = useCallback(() => {
    setIsTtsEnabled(prev => !prev);
  }, []);

  const handleToggleSpeak = useCallback((message: ChatMessage) => {
    if (!isTtsEnabled || !message.content) return;
    
    if (speakingMessageId === message.id) {
      cancel();
    } else {
      // isSpeaking from the hook is more reliable to check if something is playing
      if (isSpeaking) {
        cancel(); 
      }
      setSpeakingMessageId(message.id);
      speak(message.content);
    }
  }, [isTtsEnabled, speakingMessageId, isSpeaking, speak, cancel]);

  const isNewChat = messages.length === 1 && messages[0].role === ChatRole.MODEL;
  const toggleSidebar = () => setIsSidebarOpen(prev => !prev);

  return (
    <div className="bg-white dark:bg-black transition-colors duration-300">
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={chatSessions}
        activeChatId={activeChatId}
        onNewChat={startNewChat}
        onSwitchChat={switchChat}
        onUpdateChatTitle={updateChatTitle}
      />
      <div className={`flex flex-col h-screen overflow-hidden transition-all duration-300 ${isSidebarOpen ? 'md:pl-64' : ''}`}>
        <Header
          theme={theme}
          toggleTheme={toggleTheme}
          toggleSidebar={toggleSidebar}
          isTtsEnabled={isTtsEnabled}
          toggleTts={toggleTts}
        />
        <main className="flex-1 flex flex-col overflow-hidden relative">
          <ChatWindow
            messages={messages}
            isLoading={isLoading}
            isNewChat={isNewChat}
            chatMode={chatMode}
            onSendMessage={sendMessage}
            speakingMessageId={speakingMessageId}
            onToggleSpeak={handleToggleSpeak}
          />
          {error && <div className="p-4 text-red-500 bg-red-100 dark:bg-red-900/50 border-t border-b border-red-200 dark:border-red-800">{error}</div>}
          <div className="p-4 border-t border-gray-200 dark:border-gray-800">
            <ChatInput
              onSendMessage={sendMessage}
              isLoading={isLoading}
              chatMode={chatMode}
              setChatMode={setChatMode}
            />
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
