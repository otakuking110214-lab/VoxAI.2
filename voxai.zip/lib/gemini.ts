import { GoogleGenAI } from '@google/genai';

let ai: GoogleGenAI | null = null;

export const getGenerativeAI = (): GoogleGenAI => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
  }
  if (!ai) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return ai;
};
