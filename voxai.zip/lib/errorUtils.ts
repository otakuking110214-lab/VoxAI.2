
export const getFriendlyErrorMessage = (error: any): string => {
  const defaultMessage = "An unexpected error occurred. Please try again later.";
  
  if (!error) {
    return defaultMessage;
  }

  // Convert to string to safely search for keywords
  const errorMessage = String(error.message || error).toLowerCase();

  if (errorMessage.includes('quota') || errorMessage.includes('resource_exhausted') || errorMessage.includes('429')) {
    return "You've exceeded the API request limit for today. Please try again tomorrow or check your API plan and billing details.";
  }

  if (errorMessage.includes('api_key') && (errorMessage.includes('invalid') || errorMessage.includes('not valid'))) {
    return "The provided API key is invalid. Please check your configuration.";
  }
  
  if (errorMessage.includes('fetch failed') || errorMessage.includes('network request failed')) {
      return "A network error occurred. Please check your internet connection and try again.";
  }
  
  if (errorMessage.includes('candidate was blocked')) {
    return "The response was blocked due to the safety policy. Please adjust your prompt.";
  }

  // Return the original message if it's somewhat readable, otherwise the default.
  return error.message || defaultMessage;
};
